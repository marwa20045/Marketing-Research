import React from 'react';
import { Target, ThumbsUp, ThumbsDown } from 'lucide-react';
import { motion } from 'framer-motion';

const CompetitorAuditor = ({ data }) => {
  return (
    <motion.div 
      className="glass-panel"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
    >
      <h2 className="heading-secondary">
        <Target size={24} color="var(--color-accent)" />
        Competitor Auditor / تحليل المنافسين
      </h2>
      
      <div style={{ overflowX: 'auto', marginTop: '20px' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', color: 'var(--color-text-muted)' }}>
              <th style={{ padding: '12px 16px', fontWeight: '600' }}>Competitor</th>
              <th style={{ padding: '12px 16px', fontWeight: '600' }}>Price Point</th>
              <th style={{ padding: '12px 16px', fontWeight: '600' }}>Customer Sentiment</th>
              <th style={{ padding: '12px 16px', fontWeight: '600' }}>Pain Points (Weaknesses)</th>
            </tr>
          </thead>
          <tbody>
            {data.competitors.map((comp, idx) => (
              <motion.tr 
                key={idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + (idx * 0.1) }}
                style={{ borderBottom: idx !== data.competitors.length - 1 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}
              >
                <td style={{ padding: '16px', fontWeight: 'bold' }}>{comp.name}</td>
                <td style={{ padding: '16px' }}>
                  <span style={{
                    padding: '4px 8px', borderRadius: '4px', fontSize: '0.85rem',
                    background: comp.price_point === 'High' ? 'rgba(239, 68, 68, 0.2)' : 
                               comp.price_point === 'Medium' ? 'rgba(255, 107, 0, 0.2)' : 'rgba(16, 185, 129, 0.2)',
                    color: comp.price_point === 'High' ? 'var(--color-danger)' : 
                           comp.price_point === 'Medium' ? 'var(--color-accent)' : 'var(--color-success)',
                  }}>
                    {comp.price_point}
                  </span>
                </td>
                <td style={{ padding: '16px', width: '25%' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{ flexGrow: 1, height: '8px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
                      <div style={{
                        height: '100%',
                        width: `${comp.sentiment}%`,
                        background: comp.sentiment >= 75 ? 'var(--color-success)' : comp.sentiment >= 60 ? 'var(--color-accent)' : 'var(--color-danger)'
                      }} />
                    </div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 'bold' }}>{comp.sentiment}%</span>
                  </div>
                </td>
                <td style={{ padding: '16px' }}>
                  <ul style={{ margin: 0, paddingLeft: '20px', color: 'var(--color-danger)', fontSize: '0.9rem' }}>
                    {comp.pain_points.map((pt, i) => (
                      <li key={i} style={{ marginBottom: '4px' }}>{pt}</li>
                    ))}
                  </ul>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
};

export default CompetitorAuditor;
