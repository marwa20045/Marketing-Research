import React from 'react';
import { Flame, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

const TrendHunter = ({ data }) => {
  return (
    <motion.div 
      className="glass-panel"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.2 }}
    >
      <h2 className="heading-secondary">
        <Flame size={24} color="var(--color-danger)" />
        Trend Hunter (The "Heba" Tracker)
      </h2>
      <p className="text-muted" style={{ fontSize: '0.9rem', marginBottom: '20px' }}>
        What's going viral in the Saudi market currently.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {data.map((trend, idx) => (
          <motion.div 
            key={idx}
            whileHover={{ scale: 1.02, translateX: 5 }}
            style={{
              padding: '16px',
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: '8px',
              borderLeft: `4px solid ${trend.heat === 'High' ? 'var(--color-danger)' : 'var(--color-accent)'}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <div>
              <h3 style={{ margin: '0 0 4px 0', fontSize: '1rem', color: 'var(--color-text)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                {trend.title}
                {trend.heat === 'High' && <Flame size={16} color="var(--color-danger)" />}
              </h3>
              <span style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                {trend.type}
              </span>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: trend.heat === 'High' ? 'var(--color-danger)' : 'var(--color-accent)' }}>
              <TrendingUp size={18} />
              <span style={{ fontSize: '0.85rem', fontWeight: 'bold' }}>{trend.heat} Demand</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default TrendHunter;
