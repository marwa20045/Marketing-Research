import { useState } from 'react';
import Header from './components/Header';
import AudiencePersona from './components/AudiencePersona';
import CompetitorAuditor from './components/CompetitorAuditor';
import TrendHunter from './components/TrendHunter';
import StrategicRecommendations from './components/StrategicRecommendations';

// Mock Data
const MOCK_DATA = {
  audience_data: {
    demographics: [
      { group: '18-24', percentage: 45 },
      { group: '25-34', percentage: 35 },
      { group: '35+', percentage: 20 }
    ],
    platforms: ['Snapchat', 'TikTok', 'X (Twitter)'],
    slang: ['روقان', 'هبة', 'تعديل مزاج', 'قهوة مختصة']
  },
  competitor_analysis: {
    competitors: [
      { name: 'Half Million', price_point: 'Medium', sentiment: 75, pain_points: ['Long lines', 'Loud seating areas'] },
      { name: 'Jolt', price_point: 'High', sentiment: 60, pain_points: ['Overpriced', 'Limited food menu'] },
      { name: 'Barns', price_point: 'Low', sentiment: 80, pain_points: ['Varying quality', 'Drive-thru only primarily'] }
    ]
  },
  trending_now: [
    { title: 'Saudi Coffee with Cardamom', heat: 'High', type: 'Local' },
    { title: 'V60 Ethiopian Blends', heat: 'High', type: 'Specialty' },
    { title: 'Matcha Lattes', heat: 'Medium', type: 'Alternative' },
    { title: 'Cold Brew on Tap', heat: 'Medium', type: 'Specialty' }
  ],
  strategic_recommendations: [
    "Leverage TikTok for 'تعديل مزاج' (mood fixing) campaigns targeting 18-24 age group.",
    "Introduce a premium competitively priced V60 to steal market share from Jolt.",
    "Focus on fast service and comfortable seating to address competitor pain points."
  ]
};

function App() {
  const [data, setData] = useState(MOCK_DATA);
  const [loading, setLoading] = useState(false);

  const fetchMarketData = async (searchQuery) => {
    if (!searchQuery) return;
    setLoading(true);

    try {
      const response = await fetch('/webhook/market-research-v2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: searchQuery,
          productCategory: "مشروبات/أغذية",
          targetMarket: "السعودية",
          priceRange: "متوسط"
        })
      });

      if (response.ok) {
        const rawText = await response.text();
        let outer;
        try { outer = JSON.parse(rawText); } catch(e) { outer = null; }

        // n8n wraps the real JSON inside an "output" string field
        let result = null;
        if (outer && outer.output) {
          // Extract JSON from the output string (strip markdown fences if any)
          const match = outer.output.match(/\{[\s\S]*\}/);
          if (match) {
            try { result = JSON.parse(match[0]); } catch(e) {}
          }
        } else if (outer) {
          result = outer; // fallback: n8n sent JSON directly
        }

        if (!result) {
          alert('⚠️ n8n أرسل رداً فارغاً أو غير صالح. تحقق من إعدادات الـ Workflow.');
          return;
        }

        // --- Map n8n actual structure to dashboard structure ---
        // audience_data
        const aa = result.audience_data || result.audience_analysis || {};
        const mapped_audience = {
          demographics: aa.demographics || [
            { group: 'الجمهور الرئيسي', percentage: 60 },
            { group: 'جمهور ثانوي', percentage: 40 }
          ],
          platforms: aa.platforms || aa.best_channels || ['Snapchat', 'TikTok', 'Instagram'],
          slang: aa.slang || aa.pain_points || aa.top_needs || aa.preferences || []
        };

        // competitor_analysis
        const rawCA = result.competitor_analysis;
        let mapped_competitors;
        if (Array.isArray(rawCA)) {
          // n8n returned array directly
          mapped_competitors = {
            competitors: rawCA.map(c => ({
              name: c.name,
              price_point: c.price_position === 'مرتفع' ? 'High' : c.price_position === 'منخفض' ? 'Low' : 'Medium',
              sentiment: parseInt(c.market_share_estimate) || 70,
              pain_points: [c.weakness || c.strength || '']
            }))
          };
        } else if (rawCA && rawCA.competitors) {
          mapped_competitors = {
            competitors: rawCA.competitors.map(c => ({
              name: c.name,
              price_point: c.price_position === 'مرتفع' ? 'High' : c.price_position === 'منخفض' ? 'Low' : 'Medium',
              sentiment: parseInt(c.market_share_estimate) || 70,
              pain_points: [c.weakness || '']
            }))
          };
        } else {
          mapped_competitors = MOCK_DATA.competitor_analysis;
        }

        // trending_now
        const rawTrend = result.trending_now || result.market_gaps || [];
        const mapped_trends = Array.isArray(rawTrend)
          ? rawTrend.map(t => ({
              title: t.trend || t.title || t,
              heat: t.growth ? 'High' : (t.heat || 'Medium'),
              type: t.type || 'ترند'
            }))
          : MOCK_DATA.trending_now;

        // strategic_recommendations
        const sd = result.strategic_decisions || result.strategic_recommendations;
        let mapped_recs;
        if (Array.isArray(sd)) {
          mapped_recs = sd.map(r => r.decision || r);
        } else if (sd && sd.top_decisions) {
          mapped_recs = [
            ...sd.top_decisions.map(d => d.decision),
            sd.pricing_recommendation,
            ...(sd.kpis || []).slice(0, 2)
          ].filter(Boolean);
        } else {
          mapped_recs = MOCK_DATA.strategic_recommendations;
        }

        setData({
          audience_data: mapped_audience,
          competitor_analysis: mapped_competitors,
          trending_now: mapped_trends.length ? mapped_trends : MOCK_DATA.trending_now,
          strategic_recommendations: mapped_recs.length ? mapped_recs : MOCK_DATA.strategic_recommendations
        });

      } else {
        alert('⚠️ n8n أرجع خطأ: ' + response.status);
      }
    } catch (error) {
      console.error('Fetch error:', error);
      alert('⚠️ لم أتمكن من الاتصال بـ n8n. تأكد أن السيرفر يعمل.');
    } finally {
      setTimeout(() => setLoading(false), 800);
    }
  };




  return (
    <div className="app-container">
      <Header onRefresh={fetchMarketData} loading={loading} />

      {loading ? (
        <div className="flex-center" style={{ height: '50vh', flexDirection: 'column', gap: '16px' }}>
          <div className="spinner" style={{
            width: '40px', height: '40px', border: '4px solid var(--color-card)',
            borderTopColor: 'var(--color-accent)', borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }}></div>
          <p className="text-muted" style={{ fontFamily: 'Cairo' }}>Analyzing Saudi Market Data...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div className="grid-layout">
            <AudiencePersona data={data.audience_data} />
            <TrendHunter data={data.trending_now} />
          </div>

          <CompetitorAuditor data={data.competitor_analysis} />
          <StrategicRecommendations data={data.strategic_recommendations} />
        </div>
      )}
    </div>
  );
}

export default App;
