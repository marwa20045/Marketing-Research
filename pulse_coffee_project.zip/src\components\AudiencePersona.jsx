import React from 'react';
import { Users, Smartphone } from 'lucide-react';
import { motion } from 'framer-motion';

const AudiencePersona = ({ data }) => {
  return (
    <motion.div 
      className="glass-panel glass-accent-border"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <h2 className="heading-secondary">
        <Users size={24} color="var(--color-accent)" />
        Audience Persona / الجمهور
      </h2>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }}>
        <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '8px' }}>
          <h3 className="text-muted" style={{ fontSize: '0.85rem', marginBottom: '12px', textTransform: 'uppercase' }}>Demographics</h3>
          {data.demographics.map((demo, idx) => (
            <div key={idx} style={{ marginBottom: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', marginBottom: '4px' }}>
                <span>{demo.group}</span>
                <span style={{ color: 'var(--color-accent)', fontWeight: 'bold' }}>{demo.percentage}%</span>
              </div>
              <div style={{ width: '100%', height: '6px', background: '#333', borderRadius: '3px', overflow: 'hidden' }}>
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${demo.percentage}%` }}
                  transition={{ duration: 1, delay: 0.2 }}
                  style={{ height: '100%', background: 'var(--color-accent)', borderRadius: '3px' }}
                />
              </div>
            </div>
          ))}
        </div>
        
        <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '8px', display: 'flex', flexDirection: 'column' }}>
          <h3 className="text-muted" style={{ fontSize: '0.85rem', marginBottom: '12px', textTransform: 'uppercase' }}>Top Platforms</h3>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {data.platforms.map((platform, idx) => (
              <span key={idx} style={{ 
                background: 'rgba(255,255,255,0.05)', 
                border: '1px solid rgba(255,255,255,0.1)',
                padding: '6px 12px', 
                borderRadius: '16px',
                fontSize: '0.85rem',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}>
                <Smartphone size={14} />
                {platform}
              </span>
            ))}
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-muted" style={{ fontSize: '0.85rem', marginBottom: '12px', textTransform: 'uppercase' }}>Cultural Keywords (Slang)</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
          {data.slang.map((word, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ scale: 1.05, backgroundColor: 'rgba(255, 107, 0, 0.2)' }}
              style={{
                background: 'rgba(255,255,255,0.1)',
                padding: '8px 16px',
                borderRadius: '20px',
                fontSize: '1rem',
                fontWeight: '600',
                color: 'var(--color-text)',
                cursor: 'default',
                border: '1px solid rgba(255, 107, 0, 0.2)'
              }}
            >
              {word}
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default AudiencePersona;
