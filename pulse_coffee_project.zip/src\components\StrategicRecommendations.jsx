import React from 'react';
import { Lightbulb, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const StrategicRecommendations = ({ data }) => {
  return (
    <motion.div 
      className="glass-panel"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      style={{
        background: 'linear-gradient(145deg, rgba(26,26,26,0.8) 0%, rgba(255,107,0,0.05) 100%)',
        border: '1px solid rgba(255, 107, 0, 0.2)'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
        <h2 className="heading-secondary" style={{ margin: 0, color: 'var(--color-accent)' }}>
          <Lightbulb size={24} color="var(--color-accent)" />
          Strategic Recommendations
        </h2>
        <span style={{
          background: 'rgba(255, 255, 255, 0.1)',
          padding: '4px 10px',
          borderRadius: '12px',
          fontSize: '0.75rem',
          color: 'var(--color-text-muted)',
          display: 'flex',
          alignItems: 'center',
          gap: '4px'
        }}>
          <span style={{ display: 'inline-block', width: '6px', height: '6px', borderRadius: '50%', background: 'var(--color-accent)' }}></span>
          AI Generated
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '16px' }}>
        {data.map((rec, idx) => (
          <motion.div 
            key={idx}
            whileHover={{ y: -5 }}
            style={{
              background: 'rgba(0,0,0,0.4)',
              padding: '20px',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '12px',
              border: '1px solid rgba(255,255,255,0.05)'
            }}
          >
            <CheckCircle size={20} color="var(--color-success)" style={{ flexShrink: 0, marginTop: '2px' }} />
            <p style={{ margin: 0, fontSize: '0.95rem', lineHeight: '1.6' }}>
              {rec}
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default StrategicRecommendations;
