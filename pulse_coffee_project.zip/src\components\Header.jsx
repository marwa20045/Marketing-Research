import { useState } from 'react';
import { RefreshCw, Search } from 'lucide-react';
import { motion } from 'framer-motion';
import saudiDallah from '../assets/saudi_dallah.png';

const Header = ({ onRefresh, loading }) => {
  const [inputValue, setInputValue] = useState('');

  return (
    <header style={{ 
      display: 'flex', 
      justifyContent: 'space-between', 
      alignItems: 'center',
      borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
      paddingBottom: '20px',
      flexWrap: 'wrap',
      gap: '20px'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{ 
          backgroundColor: 'var(--color-accent)', 
          padding: '6px', 
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <img src={saudiDallah} alt="Saudi Dallah Coffee Pot" style={{ width: '32px', height: '32px', objectFit: 'contain' }} />
        </div>
        <div>
          <h1 className="heading-primary" style={{ margin: 0, lineHeight: 1.2 }}>Pulse Coffee</h1>
          <p className="text-muted" style={{ margin: 0, fontSize: '0.9rem' }}>Saudi Market Intelligence</p>
        </div>
      </div>
      
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{ position: 'relative' }}>
          <input 
            type="text" 
            placeholder="ابحث عن منتج، ترند، أو منافس..." 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onRefresh(inputValue)}
            style={{
              padding: '10px 16px 10px 40px',
              borderRadius: '8px',
              border: '1px solid rgba(255, 255, 255, 0.15)',
              backgroundColor: 'rgba(0, 0, 0, 0.3)',
              color: '#fff',
              outline: 'none',
              width: '280px',
              fontFamily: 'Cairo, sans-serif',
              fontSize: '0.9rem',
              transition: 'all 0.3s ease'
            }}
            onFocus={(e) => e.target.style.borderColor = 'var(--color-accent)'}
            onBlur={(e) => e.target.style.borderColor = 'rgba(255, 255, 255, 0.15)'}
          />
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255, 255, 255, 0.5)' }} />
        </div>

        <motion.button 
          className="btn-primary" 
          onClick={() => onRefresh(inputValue)}
          disabled={loading || !inputValue.trim()}
          whileHover={{ scale: inputValue.trim() && !loading ? 1.05 : 1 }}
          whileTap={{ scale: inputValue.trim() && !loading ? 0.95 : 1 }}
          style={{ opacity: (!inputValue.trim() || loading) ? 0.6 : 1 }}
        >
          <motion.div
             animate={{ rotate: loading ? 360 : 0 }}
             transition={{ repeat: loading ? Infinity : 0, duration: 1, ease: "linear" }}
          >
            <RefreshCw size={18} />
          </motion.div>
          {loading ? 'جاري التحليل...' : 'تحليل السوق'}
        </motion.button>
      </div>
    </header>
  );
};

export default Header;
